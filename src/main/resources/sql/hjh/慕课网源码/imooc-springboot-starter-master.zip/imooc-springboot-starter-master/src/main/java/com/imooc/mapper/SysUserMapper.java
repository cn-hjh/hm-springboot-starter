package com.imooc.mapper;

import com.imooc.pojo.SysUser;
import com.imooc.utils.MyMapper;

public interface SysUserMapper extends MyMapper<SysUser> {
}